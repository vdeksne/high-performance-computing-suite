def Power(X, Y):
    result = 1
    for _ in range(Y):
        result *= X
    return result